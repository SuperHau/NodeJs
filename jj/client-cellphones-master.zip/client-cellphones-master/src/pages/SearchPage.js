import React from 'react';
import Search from '../components/Search/Search';
import Header from '../components/header/Header'
function SearchPage(props) {
    return (
        <div>
            <Header></Header>
            <Search></Search>
        </div>
    );
}

export default SearchPage;