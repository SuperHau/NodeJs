import React from 'react';
import Login from '../components/login/Login';


function LoginPage(props) {
    return (
        <div>
            <Login></Login>
        </div>
    );
}

export default LoginPage;