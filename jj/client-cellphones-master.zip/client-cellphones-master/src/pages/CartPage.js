import React from 'react';
import Cart from '../components/ShoppingCart/Cart'

function CartPage(props) {
    return (
        <div>
            <Cart></Cart>
        </div>
    );
}

export default CartPage;