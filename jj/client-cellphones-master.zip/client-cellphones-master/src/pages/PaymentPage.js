import React from 'react'
import Payment from '../components/order/Payment'
export default function PaymentPage() {
    return (
        <div>
            <Payment></Payment>
        </div>
    )
}
