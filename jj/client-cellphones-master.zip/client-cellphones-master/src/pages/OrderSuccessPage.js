import React from 'react'
import VnPaySuccess from '../components/order/VnPaySuccess'

export default function OrderSuccessPage() {
    return (
        <div>
            <VnPaySuccess></VnPaySuccess>
        </div>
    )
}
