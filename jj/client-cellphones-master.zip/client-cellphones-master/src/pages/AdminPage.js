import React from "react";
import Admin from "../components/Admin/Admin";
function AdminPage(props) {
  return (
    <div>
      <Admin></Admin>
    </div>
  );
}

export default AdminPage;
