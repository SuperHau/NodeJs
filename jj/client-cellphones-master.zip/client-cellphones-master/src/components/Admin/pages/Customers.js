import React from 'react';


function Customers(props) {
    return (
        <div>
            customer
        </div>
    );
}

export default Customers;